// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import java.text.DecimalFormat;

// -------------------------------------------------------------------------
/**
 * This is the class that runs the project. It contains the main method.
 * 
 * @author Sutton
 * @version Nov 10, 2023
 */
public class ProjectRunner
{
    @SuppressWarnings("unused")
    private static GUISocialMediaWindow window;
    private static SinglyLinkedList<Influencer> influencerList;

    // ----------------------------------------------------------
    /**
     * This is the main method, it is the first method that gets called in order
     * to start the program
     * 
     * @param args
     *            Any potential arguments that can be provided to the program
     */
    public static void main(String[] args)
    {
        InputFileReader filer;

        if (args.length > 0)
        {
            filer = new InputFileReader(args[0]);
        }
        else
        {
            filer = new InputFileReader("SampleInput1_2023.csv");
        }

        influencerList = filer.getInfluencers();
        window = new GUISocialMediaWindow(influencerList);
    }
}
