// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

// -------------------------------------------------------------------------
/**
 * This is the Month enum. This helps make a lot of code look a lot cleaner
 * 
 * @author Ian
 * @version Nov 11, 2023
 */
public enum MonthEnum
{
    /**
     * The month of January
     */
    JANUARY,
    /**
     * The month of February
     */
    FEBRUARY,
    /**
     * The month of March
     */
    MARCH,
    /**
     * The month of April
     */
    APRIL,
    /**
     * The month of May
     */
    MAY,
    /**
     * The month of June
     */
    JUNE,
    /**
     * The month of July
     */
    JULY,
    /**
     * The month of August
     */
    AUGUST,
    /**
     * The month of September
     */
    SEPTEMBER,
    /**
     * The month of October
     */
    OCTOBER,
    /**
     * The month of November
     */
    NOVEMBER,
    /**
     * The month of December
     */
    DECEMBER,
    /**
     * Represents the first three months at once
     */
    FIRSTQUARTER,
    /**
     * Represents the second three months at once
     */
    SECONDQUARTER,
    /**
     * Represents the third three months at once
     */
    THIRDQUARTER,
    /**
     * Represents the fourth three months at once
     */
    FOURTHQUARTER
}
