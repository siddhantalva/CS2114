// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import java.util.*;
import list.ListInterface;

// -------------------------------------------------------------------------
/**
 * This is our implementation of a singly linked list for our project 5. It is
 * built up of a series of nodes that hold references to each node that comes
 * after it.
 * 
 * @author Ian
 * @version Nov 11, 2023
 * @param <T>
 *            The type of data that this list will hold.
 */
public class SinglyLinkedList<T>
    implements ListInterface<T>
{
    // ~ Fields ................................................................
    private int size;
    private Node head;

    // ~ Constructors ..........................................................

    /**
     * Creates a new empty SinglyLinkedList object
     */
    public SinglyLinkedList()
    {
        head = null;
        size = 0;
    }

    // ~Public Methods ........................................................


    // ----------------------------------------------------------
    /**
     * {@inheritDoc}
     */
    @Override
    public void add(T data)
    {
        Node newNode = new Node(data, head);
        head = newNode;
        size++;
    }


    // ----------------------------------------------------------
    /**
     * {@inheritDoc}
     */
    @Override
    public void add(int position, T data)
    {
        Node currentNode = head;
        if (position == 0)
        {
            add(data);
        }
        if (position > size || position < 0)
        {
            throw new IndexOutOfBoundsException();
        }
        for (int i = 0; i < position - 1; i++)
        {
            currentNode = currentNode.getNextNode();
        }
        Node newNode = new Node(data, currentNode.getNextNode());
        currentNode.setNextNode(newNode);
        size++;
    }


    // ----------------------------------------------------------
    /**
     * {@inheritDoc}
     */
    @Override
    public void clear()
    {
        head = null;
        size = 0;
    }


    // ----------------------------------------------------------
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean contains(T data)
    {
        Node currentNode = head;
        if (data == null)
        {
            return false;
        }
        while (currentNode != null)
        {
            if (currentNode.getData().equals(data))
            {
                return true;
            }
            currentNode = currentNode.getNextNode();
        }
        return false;
    }


    // ----------------------------------------------------------
    /**
     * {@inheritDoc}
     */
    @Override
    public T getEntry(int position)
    {
        Node currentNode = head;
        if (position > size || position < 0)
        {
            throw new IndexOutOfBoundsException();
        }
        for (int i = 0; i < position; i++)
        {
            currentNode = currentNode.getNextNode();
        }
        /*
         * We don't have to worry about currentNode being null because We
         * already checked to see if the position index is out of bounds. (The
         * only time it would be null)
         */
        return currentNode.getData();
    }


    // ----------------------------------------------------------
    /**
     * {@inheritDoc}
     */
    @Override
    public int getLength()
    {
        return size;
    }


    // ----------------------------------------------------------
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isEmpty()
    {
        return size == 0;
    }


    // ----------------------------------------------------------
    @SuppressWarnings("null")
    /**
     * {@inheritDoc}
     */
    @Override
    public T remove(int position)
    {
        Node currentNode = head;
        Node prevNode = null;
        if (position > size || position < 0)
        {
            throw new IndexOutOfBoundsException();
        }
        for (int i = 0; i < position; i++)
        {
            prevNode = currentNode;
            currentNode = currentNode.getNextNode();
        }
        prevNode.setNextNode(currentNode.getNextNode());
        currentNode.setNextNode(null);
        size--;
        return currentNode.getData();
    }


    // ----------------------------------------------------------
    /**
     * {@inheritDoc}
     */
    @Override
    public T replace(int position, T data)
    {
        Node currentNode = head;
        T returnData = null;
        if (position > size || position < 0)
        {
            throw new IndexOutOfBoundsException();
        }
        for (int i = 0; i < position; i++)
        {
            currentNode = currentNode.getNextNode();
        }
        returnData = currentNode.getData();
        currentNode.setData(data);
        return returnData;
    }


    /**
     * Sorts the singly linked list via insertion sort They will be sorted from
     * smallest to largest.
     * 
     * @param comparator
     *            The comparator that will be used for the given data type
     * @return The linked list that called this (which is now sorted)
     */
    public SinglyLinkedList<T> sort(Comparator<T> comparator)
    {
        if (size > 1)
        {
            Node unsortedPart = head.getNextNode();
            Node sortedPart = head;
            sortedPart.setNextNode(null);

            while (unsortedPart != null)
            {
                Node nodeToInsert = unsortedPart;
                unsortedPart = unsortedPart.getNextNode();

                T item = nodeToInsert.getData();
                Node currentNode = head;
                Node previousNode = null;

                while ((currentNode != null)
                    && (comparator.compare(item, currentNode.getData()) > 0))
                {
                    previousNode = currentNode;
                    currentNode = currentNode.getNextNode();
                }

                if (previousNode != null)
                {
                    previousNode.setNextNode(nodeToInsert);
                    nodeToInsert.setNextNode(currentNode);
                }
                else
                {
                    nodeToInsert.setNextNode(head);
                    head = nodeToInsert;
                }
            }

            return this;
        }
        return null;
    }


    /**
     * Creates a clone of the given list that has the exact same nodes and
     * values within the nodes. Peak rust brain.
     * 
     * @return An exact copy of this linked list.
     */
    public SinglyLinkedList<T> clone()
    {
        SinglyLinkedList<T> cloneList = new SinglyLinkedList<T>();
        @SuppressWarnings("unchecked")
        T[] arList = (T[])toArray();
        for (int i = 0; i < size; i++)
        {
            cloneList.add(arList[size - i - 1]);
        }
        return cloneList;
    }


    // ----------------------------------------------------------
    /**
     * {@inheritDoc}
     */
    @Override
    public Object[] toArray()
    {
        Object[] outputArray = new Object[size];
        Node currentNode = head;
        int i = 0;
        while (currentNode != null)
        {
            outputArray[i] = currentNode.getData();
            i++;
            currentNode = currentNode.getNextNode();
        }
        return outputArray;
    }

    private class Node
    {
        private Node nextNode;
        private T data;

        /**
         * Constructor method for the Node class.
         * 
         * @param data
         *            The data that the new node will hold
         * @param nextNode
         *            The node that this node will point to.
         */
        public Node(T data, Node nextNode)
        {
            this.data = data;
            this.nextNode = nextNode;
        }


        /**
         * Returns the data held by the node.
         * 
         * @return the data field. (This is a getter method for the data field)
         */
        public T getData()
        {
            return data;
        }


        /**
         * Returns the node that this node points to.
         * 
         * @return the next node in the list.
         */
        public Node getNextNode()
        {
            return nextNode;
        }


        /**
         * Sets the next node that this node points to
         * 
         * @param nextNode
         *            the node that this node will point to
         */
        public void setNextNode(Node nextNode)
        {
            this.nextNode = nextNode;
        }


        /**
         * Changes the data that the node holds
         * 
         * @param data
         *            the new data that the node will hold
         */
        public void setData(T data)
        {
            this.data = data;
        }
    }
}
