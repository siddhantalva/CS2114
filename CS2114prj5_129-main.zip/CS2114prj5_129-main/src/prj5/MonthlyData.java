// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import java.util.HashMap;

// -------------------------------------------------------------------------
/**
 *  This class is meant to hold all of the data for a month
 * 
 *  @author Sutton
 *  @version Nov 17, 2023
 */
public class MonthlyData implements Comparable<MonthlyData>
{
    private MonthEnum month;
    private int likes;
    private int posts;
    private int followers;
    private int comments;
    private int views;
    
    private static HashMap<MonthEnum, Integer> monthToIntDict;
    
    static {
        monthToIntDict = new HashMap<MonthEnum, Integer>();
        monthToIntDict.put(MonthEnum.JANUARY, 1);
        monthToIntDict.put(MonthEnum.FEBRUARY, 2);
        monthToIntDict.put(MonthEnum.MARCH, 3);
        monthToIntDict.put(MonthEnum.APRIL, 4);
        monthToIntDict.put(MonthEnum.MAY, 5);
        monthToIntDict.put(MonthEnum.JUNE, 6);
        monthToIntDict.put(MonthEnum.JULY, 7);
        monthToIntDict.put(MonthEnum.AUGUST, 8);
        monthToIntDict.put(MonthEnum.SEPTEMBER, 9);
        monthToIntDict.put(MonthEnum.OCTOBER, 10);
        monthToIntDict.put(MonthEnum.NOVEMBER, 11);
        monthToIntDict.put(MonthEnum.DECEMBER, 12);
    }
    
    // ----------------------------------------------------------
    /**
     * Create a new MonthlyData object.
     * @param month The month that this data is for
     * @param likes The amount of likes that this data holds
     * @param posts The amount of posts that this data holds
     * @param followers The amount of followers this data holds
     * @param comments The amount of comments this data holds
     * @param views The total amount of comments this data holds
     */
    public MonthlyData(MonthEnum month, int likes, int posts, int followers, 
        int comments, int views)
    {
        this.month = month;
        this.likes = likes;
        this.posts = posts;
        this.followers = followers;
        this.comments = comments;
        this.views = views;
    }
    
    // ----------------------------------------------------------
    /**
     * Getter method for the month field
     * @return the month field
     */
    public MonthEnum getMonth() {
        return month;
    }
    
    /**
     * Getter method for the likes field
     * @return the likes field
     */
    public int getLikes() {
        return likes;
    }
    
    /**
     * Getter method for the posts field
     * @return the posts field
     */
    public int getPosts() {
        return posts;
    }
    
    /**
     * Getter method for the followers field
     * @return the followers field
     */
    public int getFollowers() {
        return followers;
    }
    
    /**
     * Getter method for the comments field
     * @return the comments field
     */
    public int getComments() {
        return comments;
    }
    
    /**
     * Getter method for the views field tee hee
     * @return the views field
     */
    public int getViews() {
        return views;
    }

    /**
     * This compares two months for sorting.
     * Returns -1 if the caller MonthlyData has the earlier month.
     * 1 if it is the later month
     * 0 if they have the same month
     * @param monthData The MonthlyData class being compared
     * @return The comparison
     */
    public int compareTo(MonthlyData monthData)
    {
        if (this.toInt() < monthData.toInt()) {
            return -1;
        }
        if (this.toInt() > monthData.toInt()) {
            return 1;
        }
        return 0;
    }

    private int toInt()
    {   
        if (monthToIntDict.containsKey(month))
        {
            return monthToIntDict.get(month);
        }
        return -1;
    }

}
