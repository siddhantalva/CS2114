// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant

package prj5;

import cs2.*;
import java.awt.Color;
import java.text.DecimalFormat;

/**
 * This class represents the main window for the social media visualization. It
 * provides a GUI interface for displaying and interacting with influencer data.
 * Users can select different options to visualize the engagement rate by
 * various metrics.
 * 
 * @author Sutton (smarks27)
 * @version 12/1/23
 */

public class GUISocialMediaWindow
{
    private Color[] barColors = new Color[4];
    private Window window;
    private Shape[] bars;

    private TextShape timeLabel;
    private TextShape selectedEngagementLabel;
    private TextShape sortMethodLabel;

    private TextShape[] barNames;
    private TextShape[] barValues;

    private final int barWidth = 40;
    private final int startingBarX = 50;
    private final int barY = 400;
    private final int barGap = 100;

    private MonthEnum monthStart;
    private MonthEnum monthEnd;

    private SinglyLinkedList<Influencer> influencerList;

    private String activeEngagement;

    private String sortMethod;
    private String timePeriod;

    private static final double MAX_HEIGHT = 300;

    private static final int BAR_LABEL_GAP = 10;

    /**
     * Constructs a SocialMediaWindow object. Initializes the GUI elements and
     * sets up the visualization window.
     * 
     * @param influencers
     *            The list of influencers to be displayed.
     */
    public GUISocialMediaWindow(SinglyLinkedList<Influencer> influencers)
    {
        influencerList = influencers;
        // Window setup and button initialization
        window = new Window("Social Media Vis");
        window.setSize(900, 600);

        Button traditionalButton = new Button("Traditional Engagement Rate");
        Button reachButton = new Button("Reach Engagement Rate");

        traditionalButton.onClick(this, "clickedTraditional");
        reachButton.onClick(this, "clickedReach");

        window.addButton(traditionalButton, WindowSide.WEST);
        window.addButton(reachButton, WindowSide.WEST);

        Button sortChannelButton = new Button("Sort by Channel Name");
        Button sortEngagementButton = new Button("Sort by Engagement Rate");
        Button quitButton = new Button("Quit");

        sortChannelButton.onClick(this, "clickedSortChannel");
        sortEngagementButton.onClick(this, "clickedSortEngagement");
        quitButton.onClick(this, "clickedQuit");

        window.addButton(sortChannelButton, WindowSide.NORTH);
        window.addButton(sortEngagementButton, WindowSide.NORTH);
        window.addButton(quitButton, WindowSide.NORTH);

        Button januaryButton = new Button("January");
        Button februaryButton = new Button("February");
        Button marchButton = new Button("March");
        Button firstQuarterButton = new Button("First Quarter (Jan - March)");

        januaryButton.onClick(this, "clickedJanuary");
        februaryButton.onClick(this, "clickedFebruary");
        marchButton.onClick(this, "clickedMarch");
        firstQuarterButton.onClick(this, "clickedFirstQuarter");

        window.addButton(januaryButton, WindowSide.SOUTH);
        window.addButton(februaryButton, WindowSide.SOUTH);
        window.addButton(marchButton, WindowSide.SOUTH);
        window.addButton(firstQuarterButton, WindowSide.SOUTH);

        timeLabel = new TextShape(10, 10, "Time Frame");
        selectedEngagementLabel = new TextShape(
            10,
            10 + timeLabel.getHeight() + 5,
            "Selected Engagement Rate");
        sortMethodLabel = new TextShape(
            10,
            selectedEngagementLabel.getY() + selectedEngagementLabel.getHeight()
                + 5,
            "Sorting Method");

        window.addShape(timeLabel);
        window.addShape(selectedEngagementLabel);
        window.addShape(sortMethodLabel);

        barColors[0] = new Color(240, 145, 67);
        barColors[1] = new Color(80, 113, 202);
        barColors[2] = new Color(27, 72, 97);
        barColors[3] = new Color(71, 182, 124);

        bars = new Shape[4];
        barNames = new TextShape[4];
        barValues = new TextShape[4];

        // Initializing default values and updating the UI
        initializeDefaults();
        updateUI();
    }


    /**
     * Initializes default values for engagement type, sort method, and time
     * period.
     */
    private void initializeDefaults()
    {
        // Set default values for various parameters
        activeEngagement = "Traditional";
        sortMethod = "Channel Name";
        timePeriod = "First Quarter (Jan - March)";
        monthStart = MonthEnum.JANUARY;
        monthEnd = MonthEnum.MARCH;
    }


    /**
     * Updates the UI based on the current state of the window. Sorts the
     * influencer list and updates the visualization accordingly.
     */
    private void updateUI()
    {
        // Code to update the visualization based on the selected parameters
        SinglyLinkedList<Influencer> unsortedClone = influencerList.clone();
        SinglyLinkedList<Influencer> sortedList;

        DecimalFormat df = new DecimalFormat("#.#");

        timeLabel.setText(timePeriod);
        selectedEngagementLabel.setText(activeEngagement + " Engagement Rate");
        sortMethodLabel.setText("Sorting by " + sortMethod);

        switch (sortMethod)
        {
            case "Channel Name":
                sortedList = unsortedClone.sort(new CompareByNameComparator());
                break;
            case "Engagement Rate":
                if (activeEngagement.equals("Traditional"))
                {
                    sortedList = unsortedClone.sort(
                        new CompareByEngagementRateComparator(
                            monthStart,
                            monthEnd));
                    break;
                }
                else if (activeEngagement.equals("Reach"))
                {
                    sortedList = unsortedClone.sort(
                        new CompareByReachEngagementComparator(
                            monthStart,
                            monthEnd));
                    break;
                }
                sortedList = unsortedClone;
            default:
                sortedList = unsortedClone;
        }

        if (activeEngagement.equals("Traditional"))
        {
            int maxHeight = calculateMaxHeight(sortedList, "Traditional");
            for (int i = 0; i < bars.length; i++)
            {
                if (bars[i] != null)
                {
                    window.removeShape(bars[i]);
                }
                if (barNames[i] != null)
                {
                    window.removeShape(barNames[i]);
                }
                double height = scale(
                    sortedList.getEntry(i).calculateTraditionalEngagementRate(
                        monthStart,
                        monthEnd),
                    maxHeight);
                if (height >= MAX_HEIGHT)
                {
                    height = MAX_HEIGHT;
                }
                int xPosition = startingBarX + (i) * barWidth + (i) * barGap;
                bars[i] = new Shape(
                    xPosition,
                    (int)(barY - height),
                    barWidth,
                    (int)height,
                    barColors[i]);
                window.addShape(bars[i]);
                barNames[i] = new TextShape(
                    xPosition,
                    barY + BAR_LABEL_GAP,
                    sortedList.getEntry(i).getChannelName());
                window.addShape(barNames[i]);

                if (barValues[i] != null)
                {
                    window.removeShape(barValues[i]);
                }

                barValues[i] = new TextShape(
                    xPosition,
                    barNames[i].getY() + 2 * BAR_LABEL_GAP,
                    df.format(
                        sortedList.getEntry(i)
                            .calculateTraditionalEngagementRate(
                                monthStart,
                                monthEnd)));
                window.addShape(barValues[i]);
            }
        }
        else if (activeEngagement.equals("Reach"))
        {
            int maxHeight = calculateMaxHeight(sortedList, "Reach");
            for (int i = 0; i < bars.length; i++)
            {
                if (bars[i] != null)
                {
                    window.removeShape(bars[i]);
                }
                if (barNames[i] != null)
                {
                    window.removeShape(barNames[i]);
                }
                double height = scale(
                    sortedList.getEntry(i)
                        .calculateReachEngagementRate(monthStart, monthEnd),
                    maxHeight);

                int xPosition = startingBarX + (i) * barWidth + (i) * barGap;
                bars[i] = new Shape(
                    xPosition,
                    (int)(barY - height),
                    barWidth,
                    (int)height,
                    barColors[i]);
                window.addShape(bars[i]);
                barNames[i] = new TextShape(
                    xPosition,
                    barY + BAR_LABEL_GAP,
                    sortedList.getEntry(i).getChannelName());
                window.addShape(barNames[i]);

                if (barValues[i] != null)
                {
                    window.removeShape(barValues[i]);
                }

                barValues[i] = new TextShape(
                    xPosition,
                    barNames[i].getY() + 2 * BAR_LABEL_GAP,
                    df.format(
                        sortedList.getEntry(i).calculateReachEngagementRate(
                            monthStart,
                            monthEnd)));
                window.addShape(barValues[i]);
            }
        }
    }


    /**
     * Calculates the maximum height for the bars in the visualization.
     * 
     * @param sortedList
     *            The sorted list of influencers.
     * @param method
     *            The engagement rate calculation method (Traditional/Reach).
     * @return The maximum height for the bars.
     */
    private int calculateMaxHeight(
        SinglyLinkedList<Influencer> sortedList,
        String method)
    {
        double maxHeight = 0;

        if (method.equals("Traditional"))
        {
            for (int i = 0; i < sortedList.getLength(); i++)
            {
                if (sortedList.getEntry(i).calculateTraditionalEngagementRate(
                    monthStart,
                    monthEnd) > maxHeight)
                {
                    maxHeight = sortedList.getEntry(i)
                        .calculateTraditionalEngagementRate(
                            monthStart,
                            monthEnd);
                }
            }
        }
        else if (method.equals("Reach"))
        {
            for (int i = 0; i < sortedList.getLength(); i++)
            {
                if (sortedList.getEntry(i).calculateReachEngagementRate(
                    monthStart,
                    monthEnd) > maxHeight)
                {
                    maxHeight = sortedList.getEntry(i)
                        .calculateReachEngagementRate(monthStart, monthEnd);
                }
            }
        }
        return (int)maxHeight;
    }


    /**
     * Scales the engagement rate to fit within the visualization window.
     * 
     * @param engagementRate
     *            The engagement rate to be scaled.
     * @param maxHeight
     *            The maximum height for the bars.
     * @return The scaled height.
     */
    private double scale(double engagementRate, int maxHeight)
    {
        double height = engagementRate;
        if (height > maxHeight)
        {
            height = maxHeight;
        }
        return Math.max(((height) / (maxHeight) * MAX_HEIGHT), 1.0);
    }


    /**
     * Event handler for the 'Traditional Engagement Rate' button. Sets the
     * active engagement type to 'Traditional' and updates the UI.
     *
     * @param button
     *            The button that was clicked.
     */
    public void clickedTraditional(Button button)
    {
        activeEngagement = "Traditional";
        updateUI();
    }


    /**
     * Event handler for the 'Reach Engagement Rate' button. Sets the active
     * engagement type to 'Reach' and updates the UI.
     *
     * @param button
     *            The button that was clicked.
     */
    public void clickedReach(Button button)
    {
        activeEngagement = "Reach";
        updateUI();
    }


    /**
     * Event handler for the 'Sort by Channel Name' button. Sets the sorting
     * method to 'Channel Name' and updates the UI.
     *
     * @param button
     *            The button that was clicked.
     */
    public void clickedSortChannel(Button button)
    {
        sortMethod = "Channel Name";
        updateUI();
    }


    /**
     * Event handler for the 'Sort by Engagement Rate' button. Sets the sorting
     * method to 'Engagement Rate' and updates the UI.
     *
     * @param button
     *            The button that was clicked.
     */
    public void clickedSortEngagement(Button button)
    {
        sortMethod = "Engagement Rate";
        updateUI();
    }


    /**
     * Event handler for the 'Quit' button. Terminates the application.
     *
     * @param button
     *            The button that was clicked.
     */
    public void clickedQuit(Button button)
    {
        System.exit(0);
    }


    /**
     * Event handler for the 'January' button. Sets the time period to January
     * and updates the UI.
     *
     * @param button
     *            The button that was clicked.
     */
    public void clickedJanuary(Button button)
    {
        monthStart = MonthEnum.JANUARY;
        monthEnd = MonthEnum.JANUARY;
        timePeriod = "January";
        updateUI();
    }


    /**
     * Event handler for the 'February' button. Sets the time period to February
     * and updates the UI.
     *
     * @param button
     *            The button that was clicked.
     */
    public void clickedFebruary(Button button)
    {
        monthStart = MonthEnum.FEBRUARY;
        monthEnd = MonthEnum.FEBRUARY;
        timePeriod = "February";
        updateUI();
    }


    /**
     * Event handler for the 'March' button. Sets the time period to March and
     * updates the UI.
     *
     * @param button
     *            The button that was clicked.
     */
    public void clickedMarch(Button button)
    {
        monthStart = MonthEnum.MARCH;
        monthEnd = MonthEnum.MARCH;
        timePeriod = "March";
        updateUI();
    }


    /**
     * Event handler for the 'First Quarter (Jan - March)' button. Sets the time
     * period to the first quarter of the year and updates the UI.
     *
     * @param button
     *            The button that was clicked.
     */
    public void clickedFirstQuarter(Button button)
    {
        monthStart = MonthEnum.JANUARY;
        monthEnd = MonthEnum.MARCH;
        timePeriod = "First Quarter (Jan - March)";
        updateUI();
    }
}
