// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import java.util.ArrayList;

/**
 * Tests for the Influencer class. This test suite covers all methods in the
 * Influencer class, ensuring they work as expected under various scenarios.
 *
 * @author Siddhant Alva
 * @version 1-Dec-2023
 */
public class InfluencerTest
    extends student.TestCase
{
    private Influencer influencer;
    private MonthlyData monthDataJan;
    private MonthlyData monthDataFeb;

    /**
     * Set up for tests. This method initializes an Influencer instance and some
     * MonthlyData instances.
     */
    public void setUp()
    {
        // Initialize the Influencer object with basic information
        influencer =
            new Influencer("username", "channelName", "country", "mainTopic");

        // Create MonthlyData objects for different months with hypothetical
        // data
        monthDataJan =
            new MonthlyData(MonthEnum.JANUARY, 1000, 50, 5000, 200, 10000);
        monthDataFeb =
            new MonthlyData(MonthEnum.FEBRUARY, 1200, 60, 5500, 220, 11000);
        MonthlyData monthDataMar =
            new MonthlyData(MonthEnum.MARCH, 1500, 70, 6000, 250, 12000);

        // Add the MonthlyData objects to the Influencer

        influencer.addMonthData(monthDataJan);
        influencer.addMonthData(monthDataFeb);
        influencer.addMonthData(monthDataMar);
    }


    /**
     * test method for the get channel name
     */
    public void testGetChannelName()
    {
        assertEquals("channelName", influencer.getChannelName());
    }


    /**
     * test method for the get Username
     */
    public void testGetUsername()
    {
        assertEquals("username", influencer.getUsername());
    }


    /**
     * test method for the get Country
     */
    public void testGetCountry()
    {
        assertEquals("country", influencer.getCountry());
    }


    /**
     * test method for the get Main Topic
     */
    public void testGetMainTopic()
    {
        assertEquals("mainTopic", influencer.getMainTopic());
    }


    /**
     * test method for the get Month Data List
     */
    public void testGetMonthDataList()
    {
        ArrayList<MonthlyData> monthDataList = influencer.getMonthDataList();
        assertEquals(3, monthDataList.size());
        assertTrue(monthDataList.contains(monthDataJan));
        assertTrue(monthDataList.contains(monthDataFeb));
    }


    /**
     * test method for the get Monthly Data
     */
    public void testGetMonthlyData()
    {
        // Test retrieving data for a month that exists in the records
        MonthlyData retrievedJanData =
            influencer.getMonthlyData(MonthEnum.JANUARY);
        assertNotNull(
            "Monthly data for January should not be null",
            retrievedJanData);
        assertEquals(
            "Retrieved data for January should match the added data",
            monthDataJan,
            retrievedJanData);

        // Test retrieving data for a month that does not exist in the records
        MonthlyData retrievedAprData =
            influencer.getMonthlyData(MonthEnum.APRIL);
        assertNull(retrievedAprData);
    }


    /**
     * test method for the Calculate Traditional Engagement Rate
     */
    public void testCalculateTraditionalEngagementRate()
    {
        // Calculate the total comments and likes for January and February
        double totalComments =
            monthDataJan.getComments() + monthDataFeb.getComments();
        double totalLikes = monthDataJan.getLikes() + monthDataFeb.getLikes();

        // The followers count from the last month in the range (February)
        double followers = monthDataFeb.getFollowers();

        // Calculate the expected traditional engagement rate
        double expectedRate = ((totalComments + totalLikes) / followers) * 100;

        // Call the method to test
        double calculatedRate = influencer.calculateTraditionalEngagementRate(
            MonthEnum.JANUARY,
            MonthEnum.FEBRUARY);

        // Assert that the calculated rate is as expected
        assertEquals(expectedRate, calculatedRate, 0.01);
    }


    /**
     * test method for the Calculate Reach Engagement Rate
     */
    public void testCalculateReachEngagementRate()
    {
        // Calculate the total comments, likes, and views for January and
        // February
        double totalComments =
            monthDataJan.getComments() + monthDataFeb.getComments();
        double totalLikes = monthDataJan.getLikes() + monthDataFeb.getLikes();
        double totalViews = monthDataJan.getViews() + monthDataFeb.getViews();

        // Calculate the expected reach engagement rate
        double expectedRate = ((totalComments + totalLikes) / totalViews) * 100;

        // Call the method to test
        double calculatedRate = influencer.calculateReachEngagementRate(
            MonthEnum.JANUARY,
            MonthEnum.FEBRUARY);

        // Assert that the calculated rate is as expected
        assertEquals(expectedRate, calculatedRate, 0.01);
    }


    /**
     * test method for the Filter To Month With Data
     */
    public void testFilterToMonthWithData()
    {
        Influencer filtered = influencer.filterToMonth(MonthEnum.JANUARY);
        assertNotNull(filtered);
        assertEquals(1, filtered.getMonthDataList().size());
        assertEquals(monthDataJan, filtered.getMonthDataList().get(0));
    }


    /**
     * test method for the Filter To Month With No Data
     */
    public void testFilterToMonthNoData()
    {
        // Filter the influencer data to a month that has no data (e.g., March)
        Influencer filteredInfluencer =
            influencer.filterToMonth(MonthEnum.APRIL);

        assertNotNull(
            "Filtered influencer should not be null",
            filteredInfluencer);
        assertTrue(filteredInfluencer.getMonthDataList().isEmpty());

        Influencer emptyInfluencer = new Influencer("A", "B", "C", "D");
        assertNull(emptyInfluencer.filterToMonth(MonthEnum.JANUARY));

        monthDataJan = new MonthlyData(MonthEnum.JANUARY, 0, 0, 0, 0, 0);

        // Add the MonthlyData objects to the Influencer
        emptyInfluencer.addMonthData(monthDataJan);

        assertEquals(
            emptyInfluencer.calculateReachEngagementRate(
                MonthEnum.JANUARY,
                MonthEnum.JANUARY),
            -Double.MAX_VALUE,
            0.1);
    }


    /**
     * test method for the Add Month Data
     */
    public void testAddMonthData()
    {
        // Create new MonthlyData for March
        MonthlyData newMonthData =
            new MonthlyData(MonthEnum.MARCH, 200, 70, 1200, 70, 6000);

        // Check the size of monthData list before adding new data
        int originalSize = influencer.getMonthDataList().size();

        // Add the new MonthlyData
        influencer.addMonthData(newMonthData);

        // Check the size after adding and if the list contains the new data
        assertEquals(originalSize + 1, influencer.getMonthDataList().size());
        assertTrue(influencer.getMonthDataList().contains(newMonthData));
    }


    /**
     * test method for the Engagement Rate Month Index
     */
    public void testEngagementRateUsesCorrectMonthIndex()
    {
        // Assuming calculateTraditionalEngagementRate uses
        // getIndexOfTargetMonth
        double engagementRate = influencer.calculateTraditionalEngagementRate(
            MonthEnum.JANUARY,
            MonthEnum.FEBRUARY);

        // Check if the engagement rate is calculated correctly
        // This indirectly verifies that getIndexOfTargetMonth returned the
        // correct index
        double expectedRate =
            ((double)(monthDataJan.getLikes() + monthDataJan.getComments()
                + monthDataFeb.getLikes() + monthDataFeb.getComments())
                / (double)monthDataFeb.getFollowers()) * 100;
        assertEquals(
            "Engagement rate should be calculated correctly using the right"
                + " month indices",
            expectedRate,
            engagementRate,
            0.01);
    }


    /**
     * test method for Get Index Of Target Month Present
     */
    public void testGetIndexOfTargetMonthPresent()
    {
        int index = influencer.getIndexOfTargetMonth(MonthEnum.JANUARY);
        assertEquals("Index for January should be 0", 0, index);

        // You may add more assertions if you add more months in setUp
    }


    /**
     * test method for Get Index Of Target Month Not Present
     */
    public void testGetIndexOfTargetMonthNotPresent()
    {
        int index = influencer.getIndexOfTargetMonth(MonthEnum.APRIL);
        assertEquals("Index for a month not present should be -1", -1, index);
    }


    /**
     * test method for Get Index Of Target Month Empty List
     */
    public void testGetIndexOfTargetMonthEmptyList()
    {
        Influencer emptyInfluencer =
            new Influencer("user", "channel", "country", "topic");
        int index = emptyInfluencer.getIndexOfTargetMonth(MonthEnum.JANUARY);
        assertEquals(
            "Index for any month in an empty list should be -1",
            -1,
            index);
    }
}
