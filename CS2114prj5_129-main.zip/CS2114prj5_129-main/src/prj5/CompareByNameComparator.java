// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import java.util.Comparator;

/**
 * This class serves as a comparator for the Influencer class. It compares
 * influencers based on their channel names in a case-insensitive manner. 
 * This comparator is used for sorting Influencer objects alphabetically 
 * by their channel names. It implements the Comparator interface from 
 * the Java Collections Framework.
 * 
 * @author Sutton, Ian
 * @version Nov 17, 2023
 */
public class CompareByNameComparator implements Comparator<Influencer> {

    /**
     * Compares two influencers based on their channel names. The comparison
     * is case-insensitive, meaning 'ABC' and 'abc' are considered equal.
     * 
     * @param influencerLeft The first influencer to be compared.
     * @param influencerRight The second influencer to be compared.
     * @return An integer indicating the order of the influencers. 
     *         It returns -1 if influencerLeft comes before influencerRight, 
     *         1 if influencerLeft comes after influencerRight, 
     *         and 0 if they are equal.
     */
    @Override
    public int compare(Influencer influencerLeft, Influencer influencerRight) {
        String leftChannelName = 
            influencerLeft.getChannelName().toLowerCase();
        String rightChannelName = 
            influencerRight.getChannelName().toLowerCase();

        if (leftChannelName.compareTo(rightChannelName) < 0) {
            return -1;
        } 
        else if (leftChannelName.compareTo(rightChannelName) > 0) {
            return 1;
        }
        else {
            return 0;
        }
    }
}
