// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import java.util.Comparator;

/**
 * This class provides a comparator for the Influencer class, allowing
 * comparison based on traditional engagement rates over two specified months.
 * It implements the Comparator interface, applying custom sorting logic.
 * 
 * @author Sutton (smarks27)
 * @version Nov 17, 2023
 */
public class CompareByEngagementRateComparator
    implements Comparator<Influencer>
{
    // Instance variables to hold the two months for comparison.
    private MonthEnum month1;
    private MonthEnum month2;

    /**
     * Constructor for the comparator. Initializes the months to be used for
     * calculating engagement rates.
     * 
     * @param month1
     *            The first month for the engagement rate comparison.
     * @param month2
     *            The second month for the engagement rate comparison.
     */
    public CompareByEngagementRateComparator(MonthEnum month1, 
        MonthEnum month2) {
        this.month1 = month1;
        this.month2 = month2;
    }


    /**
     * Compares two influencers based on their engagement rates over the
     * specified months. Returns a negative integer, zero, or a positive integer
     * as the first argument is less than, equal to, or greater than the second,
     * in terms of engagement rates.
     * 
     * @param influencerLeft
     *            The first influencer to be compared.
     * @param influencerRight
     *            The second influencer to be compared.
     * @return An integer indicating the order of the influencers based on
     *             engagement rates.
     */
    @Override
    public int compare(Influencer influencerLeft, Influencer influencerRight)
    {
        double engagementRateLeft =
            influencerLeft.calculateTraditionalEngagementRate(month1, month2);
        double engagementRateRight =
            influencerRight.calculateTraditionalEngagementRate(month1, month2);

        if (engagementRateLeft > engagementRateRight)
        {
            return -1;
        }
        else if (engagementRateLeft < engagementRateRight)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}
