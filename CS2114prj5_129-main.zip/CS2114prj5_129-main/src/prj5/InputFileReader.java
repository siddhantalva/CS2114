// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import java.util.Scanner;
import student.IOHelper;

/**
 * This class is responsible for reading a CSV file and converting it into a linked list of Influencer objects.
 * It parses the CSV data, creating Influencer objects and their associated MonthlyData.
 * 
 * @author Sutton
 * @version 18-Nov-2023
 */
public class InputFileReader {
    private SinglyLinkedList<Influencer> influencers;

    /**
     * Returns the list of influencers.
     * 
     * @return SinglyLinkedList of Influencer objects
     */
    public SinglyLinkedList<Influencer> getInfluencers() {
        return influencers;
    }

    /**
     * Constructs a new InputFileReader.
     * It reads the specified file and initializes the list of influencers.
     * 
     * @param fileName The name of the file to be read.
     */
    public InputFileReader(String fileName) {
        influencers = readListFile(fileName);
    }

    /**
     * Reads the CSV file and builds a linked list of influencers.
     * Each line of the file is parsed into an Influencer object and their corresponding MonthlyData.
     * 
     * @param fileName The name of the file to be read.
     * @return SinglyLinkedList of Influencer objects.
     */
    private SinglyLinkedList<Influencer> readListFile(String fileName) {
        SinglyLinkedList<Influencer> influencerList = new SinglyLinkedList<Influencer>();
        Scanner inStream = IOHelper.createScanner(fileName);
        inStream.nextLine(); // Skip the header line
        while (inStream.hasNextLine()) {
            String line = inStream.nextLine().replaceAll(" ", "");
            String[] values = line.split(",");
            String month = values[0];
            String username = values[1];
            String channel = values[2];
            String country = values[3];
            String mainTopic = values[4];
            int likes = toInt(values[5]);
            int posts = toInt(values[6]);
            int followers = toInt(values[7]);
            int comments = toInt(values[8]);
            int views = toInt(values[9]);

            // Add new influencer or update existing influencer's data
            boolean containsUsername = false;
            for (int i = 0; i < influencerList.getLength(); i++) {
                if (influencerList.getEntry(i).getUsername().equals(username)) {
                    influencerList.getEntry(i).addMonthData(
                        new MonthlyData(getMonth(month), likes, posts, followers, comments, views));
                    containsUsername = true;
                    break;
                }
            }
            if (!containsUsername) {
                Influencer influencer = new Influencer(username, channel, country, mainTopic);
                influencer.addMonthData(
                    new MonthlyData(getMonth(month), likes, posts, followers, comments, views));
                influencerList.add(influencer);
            }
        }
        return influencerList;
    }

    /**
     * Converts a String to an integer, returning 0 in case of an exception.
     * 
     * @param str The string to convert to an integer.
     * @return The integer value of the string, or 0 if conversion fails.
     */
    private int toInt(String str) {
        try {
            return Integer.parseInt(str);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Converts a month's name to its corresponding Month enum value.
     * 
     * @param month The name of the month.
     * @return The corresponding Month enum value.
     */
    private MonthEnum getMonth(String month) {
        switch (month) {
            case "January":
                return MonthEnum.JANUARY;
            case "February":
                return MonthEnum.FEBRUARY;
            case "March":
                return MonthEnum.MARCH;
            case "April":
                return MonthEnum.APRIL;
            case "May":
                return MonthEnum.MAY;
            case "July":
                return MonthEnum.JULY;
            case "August":
                return MonthEnum.AUGUST;
            case "September":
                return MonthEnum.SEPTEMBER;
            case "October":
                return MonthEnum.OCTOBER;
            case "November":
                return MonthEnum.NOVEMBER;
            case "December":
                return MonthEnum.DECEMBER;
            default:
                return null;
        }
    }
}
