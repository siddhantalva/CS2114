// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import java.util.Comparator;

/**
 * This class provides a comparator for the Influencer class, allowing
 * comparison based on reach engagement rates over two specified months. It
 * implements the Comparator interface, applying custom sorting logic for reach
 * engagement rate, which is a specific measure of social media performance.
 * 
 * @author Sutton (smarks27)
 * @version Nov 17, 2023
 */
public class CompareByReachEngagementComparator
    implements Comparator<Influencer>
{
    // Instance variables to hold the two months for comparison.
    private MonthEnum month1;
    private MonthEnum month2;

    /**
     * Constructor for the comparator. Initializes the months to be used for
     * calculating reach engagement rates.
     * 
     * @param month1
     *            The first month for the reach engagement rate comparison.
     * @param month2
     *            The second month for the reach engagement rate comparison.
     */
    public CompareByReachEngagementComparator(
        MonthEnum month1,
        MonthEnum month2)
    {
        this.month1 = month1;
        this.month2 = month2;
    }


    /**
     * Compares two influencers based on their reach engagement rates over the
     * specified months. Returns a negative, zero, or  positive integer as the
     * first argument has a higher, equal, or lower reach engagement rate
     * compared to the second.
     * 
<<<<<<< HEAD
     * @param influencerLeft The first influencer to be compared.
     * @param influencerRight The second influencer to be compared.
     * @return An integer indicating the order of the influencers based on
     * reach engagement rates.
     */
    @Override
    public int compare(Influencer influencerLeft, Influencer influencerRight) {
        double reachRateLeft = 
            influencerLeft.calculateReachEngagementRate(month1, month2);
        double reachRateRight = 
            influencerRight.calculateReachEngagementRate(month1, month2);

        if (reachRateLeft > reachRateRight)
        {
            return -1;
        }
        else if (reachRateLeft < reachRateRight)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}
