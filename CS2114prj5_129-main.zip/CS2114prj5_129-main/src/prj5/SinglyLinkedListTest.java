package prj5;

import student.TestCase;

/**
 * Test all the methods for the SinglyLinkedList class
 * 
 * @author Andrew Woodhouse
 * @version 11/17/2023
 */
public class SinglyLinkedListTest
    extends TestCase
{
    private SinglyLinkedList<String> linkedListTest;
    private SinglyLinkedList<String> emptyList;

    /**
     * setup method
     */
    public void setUp()
    {
        linkedListTest = new SinglyLinkedList<String>();
        linkedListTest.add("apple");
        linkedListTest.add("banana");
        linkedListTest.add("mango");
        linkedListTest.add("kiwi");

        emptyList = new SinglyLinkedList<String>();
    }


    /**
     * testing the Add method
     */
    public void testAdd()
    {
        linkedListTest.add("standard add");
        assertTrue(linkedListTest.contains("standard add"));
        linkedListTest.add(2, "index add");
        assertTrue(linkedListTest.contains("index add"));
        linkedListTest.add(0, "0 index add");
        assertTrue(linkedListTest.contains("0 index add"));
    }


    /**
     * testing the Clear method
     */
    public void testClear()
    {
        linkedListTest.clear();
        assertTrue(linkedListTest.isEmpty());
    }


    /**
     * testing the contains method
     */
    public void testContains()
    {
        assertTrue(linkedListTest.contains("kiwi"));
        assertFalse(linkedListTest.contains(null));
    }


    /**
     * testing the Get Entry method
     */
    public void testGetEntry()
    {
        assertEquals(linkedListTest.getEntry(0), "kiwi");
    }


    /**
     * testing the Get Length method
     */
    public void testGetLength()
    {
        assertEquals(linkedListTest.getLength(), 4);
    }


    /**
     * testing the isEmpty method
     */
    public void testIsEmpty()
    {
        assertTrue(emptyList.isEmpty());
        assertFalse(linkedListTest.isEmpty());

    }


    /**
     * testing the remove method
     */
    public void testRemove()
    {
        linkedListTest.remove(3);
        assertFalse(linkedListTest.contains("apple"));
    }


    /**
     * testing the replace method
     */
    public void testReplace()
    {
        linkedListTest.replace(2, "kiki");
        assertEquals(linkedListTest.getEntry(2), "kiki");
    }


    /**
     * testing the toarray method
     */
    public void testToArray()
    {
        Object[] ween = linkedListTest.toArray();
        assertEquals(linkedListTest.getLength(), ween.length);
    }


    /**
     * testing the replace method
     */
    public void testClone()
    {
        SinglyLinkedList<String> bird = linkedListTest.clone();
        assertEquals(linkedListTest.getEntry(3), bird.getEntry(3));
        assertEquals(linkedListTest.getEntry(0), bird.getEntry(0));
        assertEquals(linkedListTest.getEntry(1), bird.getEntry(1));
    }
    
    /**
     * Tests the remove method when it should throw an exception
     */
    public void testRemoveException()
    {
        IndexOutOfBoundsException ioobe = null;
        try
        {
            emptyList.remove(-1);
        }
        catch (IndexOutOfBoundsException ioobe2)
        {
            ioobe = ioobe2;
        }
        assertNotNull(ioobe);
        
        ioobe = null;
        try
        {
            emptyList.remove(50);
        }
        catch (IndexOutOfBoundsException ioobe2)
        {
            ioobe = ioobe2;
        }
        assertNotNull(ioobe);
    }
    
    /**
     * Tests the get method when it should throw an exception
     */
    public void testGetException()
    {
        IndexOutOfBoundsException ioobe = null;
        try
        {
            emptyList.getEntry(-1);
        }
        catch (IndexOutOfBoundsException ioobe2)
        {
            ioobe = ioobe2;
        }
        assertNotNull(ioobe);
        
        ioobe = null;
        try
        {
            emptyList.getEntry(50);
        }
        catch (IndexOutOfBoundsException ioobe2)
        {
            ioobe = ioobe2;
        }
        assertNotNull(ioobe);
    }
    
    /**
     * Tests to make sure that the sort method correctly sorts a linked list
     */
    public void testSort()
    {
        SinglyLinkedList<Influencer> influencerList = 
            new SinglyLinkedList<Influencer>();
        
        Influencer alice = new Influencer("Alice", "Alice's Adventures",
            "USA", "Travel");
        Influencer bob = new Influencer("Bob", "Bob's Baking", "France",
            "Food");
        Influencer joe = new Influencer("Joe", "Joe's Journey", "England",
            "Entertainment");
        Influencer dan = new Influencer("Dan", "Dancing Dan", "USA",
            "Entertainment");
        

        influencerList.add(dan);
        influencerList.add(joe);
        influencerList.add(alice);
        influencerList.add(bob);

        influencerList.sort(new CompareByNameComparator());
        assertEquals(influencerList.getEntry(0), alice);
        assertEquals(influencerList.getEntry(1), bob);
        assertEquals(influencerList.getEntry(2), dan);
        assertEquals(influencerList.getEntry(3), joe);
        
        SinglyLinkedList<Influencer> emptyInfluencerList = 
            new SinglyLinkedList<Influencer>();
        
        emptyInfluencerList.sort(new CompareByNameComparator());
        assertNotNull(emptyInfluencerList);
        
        MonthlyData monthDataJan =
            new MonthlyData(MonthEnum.JANUARY, 1000, 50, 5000, 200, 10000);
        MonthlyData monthDataFeb =
            new MonthlyData(MonthEnum.FEBRUARY, 1200, 60, 5500, 220, 11000);
        
        MonthlyData monthDataJan2 =
            new MonthlyData(MonthEnum.JANUARY, 1200, 60, 5500, 220, 11000);
        MonthlyData monthDataFeb2 =
            new MonthlyData(MonthEnum.FEBRUARY, 1500, 70, 6000, 250, 12000);

        // Add the MonthlyData objects to the Influencer
        influencerList.getEntry(0).addMonthData(monthDataJan);
        influencerList.getEntry(0).addMonthData(monthDataFeb);
        influencerList.getEntry(1).addMonthData(monthDataJan2);
        influencerList.getEntry(1).addMonthData(monthDataFeb2);
        influencerList.getEntry(2).addMonthData(monthDataJan);
        influencerList.getEntry(2).addMonthData(monthDataFeb);
        influencerList.getEntry(3).addMonthData(monthDataJan);
        influencerList.getEntry(3).addMonthData(monthDataFeb);
        
        influencerList.sort(new 
            CompareByEngagementRateComparator(MonthEnum.JANUARY, 
                MonthEnum.FEBRUARY));
        assertEquals(influencerList.getEntry(0), bob);
        assertEquals(influencerList.getEntry(1), joe);
        assertEquals(influencerList.getEntry(2), dan);
        assertEquals(influencerList.getEntry(3), alice);
        
        emptyInfluencerList.sort(new CompareByNameComparator());
        assertNotNull(emptyInfluencerList);
        
        influencerList.sort(new 
            CompareByReachEngagementComparator(MonthEnum.JANUARY, 
                MonthEnum.FEBRUARY));
        
        assertEquals(influencerList.getEntry(0), bob);
        assertEquals(influencerList.getEntry(1), alice);
        assertEquals(influencerList.getEntry(2), dan);
        assertEquals(influencerList.getEntry(3), joe);
    }
    
    /**
     * Helps to test one of the comparators
     */
    public void testSort2()
    {
        Influencer alice = new Influencer("Alice", "Alice's Adventures", "USA",
            "Travel");
        Influencer alice2 = new Influencer("Alice", "Alice's Adventures", "UK",
            "Travel");
        
        SinglyLinkedList<Influencer> influencerList = 
            new SinglyLinkedList<Influencer>();
        
        influencerList.add(alice);
        influencerList.add(alice2);

        influencerList.sort(new CompareByNameComparator());
        
        assertEquals(influencerList.getEntry(0), alice);
        assertEquals(influencerList.getEntry(1), alice2);
    }
    
    /**
     * Tests the replace method when it should throw an exception
     */
    public void testReplaceException()
    {
        IndexOutOfBoundsException ioobe = null;
        try
        {
            emptyList.replace(-1, "index too low");
        }
        catch (IndexOutOfBoundsException ioobe2)
        {
            ioobe = ioobe2;
        }
        assertNotNull(ioobe);
        
        ioobe = null;
        try
        {
            emptyList.replace(50, "index too high");
        }
        catch (IndexOutOfBoundsException ioobe2)
        {
            ioobe = ioobe2;
        }
        assertNotNull(ioobe);
    }
    
    /**
     * Tests the add method when it should throw an exception
     */
    public void testAddException()
    {
        IndexOutOfBoundsException ioobe = null;
        try
        {
            emptyList.add(-1, "index too low");
        }
        catch (IndexOutOfBoundsException ioobe2)
        {
            ioobe = ioobe2;
        }
        assertNotNull(ioobe);
        
        ioobe = null;
        try
        {
            emptyList.add(50, "add too high");
        }
        catch (IndexOutOfBoundsException ioobe2)
        {
            ioobe = ioobe2;
        }
        assertNotNull(ioobe);
    }
}