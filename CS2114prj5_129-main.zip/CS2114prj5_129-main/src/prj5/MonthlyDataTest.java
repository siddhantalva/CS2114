// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import student.TestCase;

/**
 * Testing the methods in the Monthly Data Class
 * 
 * @author Andrew Woodhouse
 * @version Nov 17, 2023
 */
public class MonthlyDataTest
    extends TestCase
{
    private MonthlyData monthlyDataTesting;

    /**
     * setup method
     */
    public void setUp()
    {
        monthlyDataTesting =
            new MonthlyData(MonthEnum.FEBRUARY, 50, 3, 69, 4, 6);
    }


    /**
     * Test get month
     */
    public void testGetMonth()
    {
        assertEquals(monthlyDataTesting.getMonth(), MonthEnum.FEBRUARY);
    }


    /**
     * Test get month
     */
    public void testGetLikes()
    {
        assertEquals(monthlyDataTesting.getLikes(), 50);
    }


    /**
     * Test get Posts
     */
    public void testGetPosts()
    {
        assertEquals(monthlyDataTesting.getPosts(), 3);
    }


    /**
     * Test get Followers
     */
    public void testGetFollowers()
    {
        assertEquals(monthlyDataTesting.getFollowers(), 69);
    }


    /**
     * Test get Comments
     */
    public void testGetComments()
    {
        assertEquals(monthlyDataTesting.getComments(), 4);
    }


    /**
     * Test get views
     */
    public void testGetViews()
    {
        assertEquals(monthlyDataTesting.getViews(), 6);
    }


    /**
     * Tests compare to
     */
    public void testCompareTo()
    {
        MonthlyData monthlyDataTesting2 =
            new MonthlyData(MonthEnum.JANUARY, 50, 3, 69, 4, 6);

        assertEquals(monthlyDataTesting.compareTo(monthlyDataTesting2), 1);
        assertEquals(monthlyDataTesting2.compareTo(monthlyDataTesting), -1);
        assertEquals(monthlyDataTesting.compareTo(monthlyDataTesting), 0);

        // This case shouldn't run in actual code
        MonthlyData monthlyDataTestingWeird =
            new MonthlyData(MonthEnum.FIRSTQUARTER, 50, 3, 69, 4, 6);
        assertEquals(monthlyDataTesting2.compareTo(monthlyDataTestingWeird), 1);
    }
}
