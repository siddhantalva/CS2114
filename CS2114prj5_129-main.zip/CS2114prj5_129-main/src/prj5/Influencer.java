// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those who
// do.
// -- Sutton, Ian, Andrew, and Siddhant
package prj5;

import java.util.ArrayList;

// -------------------------------------------------------------------------
/**
 * This is the Influencer class, it holds all of the information that is
 * contained in a single line of the CSV file. It holds all of the relevant
 * getter methods, as well as formulas to calculate engagement rate.
 * 
 * @author Ian, Sutton
 * @version Nov 11, 2023
 */
public class Influencer
{
    // ~ Fields ................................................................
    private String username;
    private String channelName;
    private String mainTopic;
    private ArrayList<MonthlyData> monthData;
    private String country;

    // ~ Constructors ..........................................................
    /**
     * Creates a new Influencer object
     * 
     * @param username
     *            The username of the influencer
     * @param channelName
     *            The name of the influencer's channel
     * @param country
     *            The country of the influencer
     * @param mainTopic
     *            The topic that the channel is about
     */
    public Influencer(
        String username,
        String channelName,
        String country,
        String mainTopic)
    {
        this.username = username;
        this.channelName = channelName;
        this.country = country;
        this.mainTopic = mainTopic;
        monthData = new ArrayList<MonthlyData>();
    }
    // ~Public Methods ........................................................


    /**
     * Getter method for the channelName field of the Influencer class
     * 
     * @return The name of the channel in question
     */
    public String getChannelName()
    {
        return channelName;
    }


    /**
     * Returns the username of the channel this data is for.
     * 
     * @return the username field
     */
    public String getUsername()
    {
        return username;
    }


    /**
     * Returns the country of the channel this data is for.
     * 
     * @return the country field
     */
    public String getCountry()
    {
        return country;
    }


    /**
     * Returns the main topic that the channel this data is for is about
     * 
     * @return the mainTopic field
     */
    public String getMainTopic()
    {
        return mainTopic;
    }


    // ----------------------------------------------------------
    /**
     * Getter method for the monthData field
     * 
     * @return the monthData field
     */
    public ArrayList<MonthlyData> getMonthDataList()
    {
        return monthData;
    }


    // ----------------------------------------------------------
    /**
     * Gets all of the data for a specific month
     * 
     * @param month
     *            the month that the data is being gotten for
     * @return the full collection of data for one month
     */
    public MonthlyData getMonthlyData(MonthEnum month)
    {
        for (int i = 0; i < monthData.size(); i++)
        {
            if (monthData.get(i).getMonth().equals(month))
            {
                return monthData.get(i);
            }
        }
        return null;
    }


    /**
     * Calculates the engagement rate the traditional way. Follows this formula:
     * Engagement Rate = ((comments + likes)/ follower count) x 100
     * 
     * @param startMonth
     *            the month that the traditional engagement rate is calculated
     *            from
     * @param endMonth
     *            the month that the traditional engagement rate is calculated
     *            to
     * @return the traditionally calculated engagement rate
     */
    @SuppressWarnings("cast")
    public double calculateTraditionalEngagementRate(
        MonthEnum startMonth,
        MonthEnum endMonth)
    {
        double comments = 0;
        double likes = 0;
        double followers = 0;

        for (int i =
            getIndexOfTargetMonth(startMonth); i <= getIndexOfTargetMonth(
                endMonth); i++)
        {
            comments += monthData.get(i).getComments();
            likes += monthData.get(i).getLikes();
            if (i == getIndexOfTargetMonth(endMonth))
            {
                followers = monthData.get(i).getFollowers();
            }
        }
        return (((double)comments + (double)likes) / (double)followers) * 100.0;
    }


    private void insertionSortMonthData()
    {
        for (int i = 0; i <= monthData.size() - 1; i++)
        {
            insertMonthInOrder(monthData.get(i), monthData, 0, i - 1);
        }
    }


    private void insertMonthInOrder(
        MonthlyData anEntry,
        ArrayList<MonthlyData> arr,
        int begin,
        int end)
    {
        int index = end;
        while ((index >= begin) && (anEntry.compareTo(arr.get(index)) < 0))
        {
            arr.set(index + 1, arr.get(index));
            index--;
        }
        arr.set(index + 1, anEntry);
    }


    /**
     * Calculates the engagement rate via engagement. Follows this formula:
     * Engagement Rate by reach = ( (comments + likes)/ views) x 100% (100%
     * should just be equal to one I think)
     * 
     * @param startMonth
     *            the month that the reach engagement rate is calculated from
     * @param endMonth
     *            the month that the reach engagement rate is calculated to
     * @return the engagement rate calculated via engagement
     */
    public
        double
        calculateReachEngagementRate(MonthEnum startMonth, MonthEnum endMonth)
    {
        double comments = 0;
        double likes = 0;
        double views = 0;

        for (int i =
            getIndexOfTargetMonth(startMonth); i <= getIndexOfTargetMonth(
                endMonth); i++)
        {
            comments += monthData.get(i).getComments();
            likes += monthData.get(i).getLikes();
            views += monthData.get(i).getViews();
        }
        if (views != 0)
        {

            return ((comments + likes) / views) * 100.0;
        }
        return -Double.MAX_VALUE;
    }


    // ----------------------------------------------------------
    /**
     * A helper method to get the index of a specific month in the arraylist
     * @param endMonth the month to check for
     * @return the index of the month in the array list.
     */
    public int getIndexOfTargetMonth(MonthEnum endMonth)
    {
        insertionSortMonthData();
        int index = 0;

        for (int i = 0; i < monthData.size(); i++)
        {
            if (monthData.get(i).getMonth().toString()
                .equals(endMonth.toString()))
            {
                return index;
            }
            index++;
        }
        return -1;
    }


    /**
     * Adds a set of data to a month
     * 
     * @param newMonthData
     *            the data to be added
     */
    public void addMonthData(MonthlyData newMonthData)
    {
        this.monthData.add(newMonthData);
    }


    // ----------------------------------------------------------
    /**
     * Filters out to a specific month
     * 
     * @param month
     *            The month that is being
     * @return The influencer class with data filtered out to a specific month
     */
    public Influencer filterToMonth(MonthEnum month)
    {
        if (monthData.size() > 0)
        {
            Influencer filteredInfluencer =
                new Influencer(username, channelName, country, mainTopic);
            for (int i = 0; i < monthData.size(); i++)
            {
                if (monthData.get(i).getMonth().equals(month))
                {
                    filteredInfluencer.addMonthData(monthData.get(i));
                }
            }
            return filteredInfluencer;
        }
        return null;
    }
}
