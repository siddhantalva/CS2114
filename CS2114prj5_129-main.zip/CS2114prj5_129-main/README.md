# CS2114prj5_129

Team Member Names:
1. Andrew - AndrewkWoodhouse
2. Sutton - smarks27
3. Ian - dewittdoucette or Red-Lattice (I don't know why it insists on using my personal account)
4. Sid - siddhantalva

**Communication Plan**

We plan to communicate over Discord.

Usernames:
1. Andrew - chaoscracker
2. Sutton - smarks23
3. Ian - error_found
4. Sid - alva.wrld

Phone Numbers:
1. Andrew - 434-422-0358
2. Sutton - 804-873-1674
3. Ian - 907-903-9038
4. Sid - 540-750-5568

**Team Pledge**

All team members agree to do the following:

- abide by university policies and procedures, including the Student Code of Conduct, Principles of Community, and the Honor Code communicate regularly and show up to group meetings on time
- familiarize myself with the Project 5 Group assignment before the mandatory synchronous group meeting scheduled during week 12
- attend the mandatory synchronous group meeting scheduled during week 12 or forfeit the opportunity to work with a group.  Further, I acknowledge that not attending this session without being excused by an instructor will result in my being awarded a score of 0 for this activity 
- complete agreed upon task well in advance of deadlines to assure team members of my participation and competency
